﻿namespace CreatePicklistXML
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button1 = new System.Windows.Forms.Button();
            this.InputValues = new System.Windows.Forms.TextBox();
            this.OutputXML = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtOther = new System.Windows.Forms.TextBox();
            this.Version4 = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.version3 = new System.Windows.Forms.RadioButton();
            this.IntialTextValue = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.button1.Location = new System.Drawing.Point(11, 229);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(119, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Convert to XML";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // InputValues
            // 
            this.InputValues.Location = new System.Drawing.Point(12, 35);
            this.InputValues.Multiline = true;
            this.InputValues.Name = "InputValues";
            this.InputValues.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.InputValues.Size = new System.Drawing.Size(118, 188);
            this.InputValues.TabIndex = 1;
            // 
            // OutputXML
            // 
            this.OutputXML.Location = new System.Drawing.Point(317, 35);
            this.OutputXML.Multiline = true;
            this.OutputXML.Name = "OutputXML";
            this.OutputXML.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.OutputXML.Size = new System.Drawing.Size(260, 188);
            this.OutputXML.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 12);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(117, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Copy and Paste Values";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(314, 12);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(111, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "XML formatted Output";
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.button2.Location = new System.Drawing.Point(317, 229);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(119, 23);
            this.button2.TabIndex = 12;
            this.button2.Text = "Copy to Clipboard";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtOther);
            this.groupBox1.Controls.Add(this.Version4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.version3);
            this.groupBox1.Controls.Add(this.IntialTextValue);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(150, 28);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(145, 195);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Settings";
            // 
            // txtOther
            // 
            this.txtOther.Location = new System.Drawing.Point(10, 118);
            this.txtOther.Name = "txtOther";
            this.txtOther.Size = new System.Drawing.Size(120, 20);
            this.txtOther.TabIndex = 16;
            this.txtOther.Text = "Lang. Code ex. \"1025\"";
            this.txtOther.Visible = false;
            // 
            // Version4
            // 
            this.Version4.AutoSize = true;
            this.Version4.Location = new System.Drawing.Point(70, 39);
            this.Version4.Name = "Version4";
            this.Version4.Size = new System.Drawing.Size(40, 17);
            this.Version4.TabIndex = 15;
            this.Version4.TabStop = true;
            this.Version4.Text = "4.0";
            this.Version4.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(126, 13);
            this.label3.TabIndex = 14;
            this.label3.Text = "Microsoft Dynamics CRM";
            // 
            // version3
            // 
            this.version3.AutoSize = true;
            this.version3.Location = new System.Drawing.Point(15, 39);
            this.version3.Name = "version3";
            this.version3.Size = new System.Drawing.Size(40, 17);
            this.version3.TabIndex = 13;
            this.version3.TabStop = true;
            this.version3.Text = "3.0";
            this.version3.UseVisualStyleBackColor = true;
            // 
            // IntialTextValue
            // 
            this.IntialTextValue.Location = new System.Drawing.Point(10, 165);
            this.IntialTextValue.Name = "IntialTextValue";
            this.IntialTextValue.Size = new System.Drawing.Size(46, 20);
            this.IntialTextValue.TabIndex = 12;
            this.IntialTextValue.Text = "1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 148);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(95, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "Initial Option Value";
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Arabic - 1025",
            "Danish - 1030",
            "Dutch - 1043",
            "English - 1033",
            "French - 1036",
            "German - 1031",
            "Hungarian - 1038",
            "Italian - 1040",
            "Swedish - 1053",
            "Other"});
            this.comboBox1.Location = new System.Drawing.Point(9, 91);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 10;
            this.comboBox1.TextChanged += new System.EventHandler(this.comboBox1_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "CRM Base Language";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(589, 264);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.OutputXML);
            this.Controls.Add(this.InputValues);
            this.Controls.Add(this.button1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Convert Picklist Values to XML";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox InputValues;
        private System.Windows.Forms.TextBox OutputXML;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton Version4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton version3;
        private System.Windows.Forms.TextBox IntialTextValue;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtOther;
    }
}

