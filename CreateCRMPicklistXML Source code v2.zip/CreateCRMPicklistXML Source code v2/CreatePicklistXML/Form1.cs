﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Configuration;

namespace CreatePicklistXML
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            populateCRMBaseLanguageBox();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (version3.Checked != true && Version4.Checked != true)
            {
                MessageBox.Show("Please choose CRM Version","Error",MessageBoxButtons.OK);
                return;
            }
            if (version3.Checked)
            {
                GenerateVersion3XML();
            }
            else if(Version4.Checked)
            {
                GenerateVersion4XML();
            }
        }
        private string getLanguagecode(string selectedvalue)
        {
            if (comboBox1.SelectedText == "Other")
            {
                return txtOther.Text;
            }
            else
            {
                return selectedvalue.Substring(selectedvalue.IndexOf('-') + 1).Trim();
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(OutputXML.Text);
        }
        private void GenerateVersion4XML()
        {
            int initialValue = Convert.ToInt32(IntialTextValue.Text);
            StringBuilder sb = new StringBuilder();
            sb.Append(string.Empty);
            sb.AppendLine("<options>");
            string languagecode = getLanguagecode(comboBox1.Text);
            foreach (string line in InputValues.Lines)
            {
                if (line != "")
                {
                    sb.AppendLine("<option value=\"" + initialValue + "\">");
                    sb.AppendLine("<labels>");
                    sb.AppendLine("<label description=\"" + line + "\" languagecode=\"" + languagecode + "\" />");
                    sb.AppendLine("</labels>");
                    sb.AppendLine("</option>");
                    initialValue++;
                }
            }
            sb.AppendLine("</options>");
            OutputXML.Text = sb.ToString();
        }
        private void GenerateVersion3XML()
        {
            int initialValue = Convert.ToInt32(IntialTextValue.Text);
            StringBuilder sb = new StringBuilder();
            sb.Append(string.Empty);
            int nextvalue = initialValue + InputValues.Lines.Length;
            sb.AppendLine("<options nextvalue=" + nextvalue + "\">");
            string languagecode = getLanguagecode(comboBox1.Text);
            foreach (string line in InputValues.Lines)
            {
                if (line != "")
                {
                    sb.AppendLine("<option value=\"" + initialValue + "\">");
                    sb.AppendLine("<labels>");
                    sb.AppendLine("<label description=\"" + line + "\" languagecode=\"" + languagecode + "\" />");
                    sb.AppendLine("</labels>");
                    sb.AppendLine("</option>");
                    initialValue++;
                }
            }
            sb.AppendLine("</options>");
            OutputXML.Text = sb.ToString();
        }

        private void populateCRMBaseLanguageBox()
        {
            string LanguageFromConfig = ConfigurationSettings.AppSettings["CRMbaseLanguages"].ToString();

            string[] LanguageArray = LanguageFromConfig.Split('#');

            foreach (string language in LanguageArray )
            {
                if (language != "")
                {
                    comboBox1.Items.Add(language);
                }
            }
        }

        private void comboBox1_TextChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text == "Other")
            {
                txtOther.Visible = true;
            }
        }
    }
}
